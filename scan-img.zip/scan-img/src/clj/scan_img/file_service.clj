(ns scan-img.file-service
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [clojure.core.async :as async]
            [clj-commons-exec :as exec]
            [mount.core :as mount :refer [defstate]]))


;;--------------------------------------------------------------
;; Process an upload for scanning
;; side effects!!!
;;--------------------------------------------------------------
(defn ensure-parent-dir!
  "Check and create parent directory if it doesnt exist.
  Uses canonical path to remove OS dependent path strings.
  -> seems make-parents fails gracefully returning false
  in case of error !!!!"
  [f]
  (let [can-path (.getCanonicalPath f)
        parent-file (io/as-file (.getParent f))]
    
    (if (not (.isDirectory parent-file))
      (io/make-parents can-path))
    can-path))

;;--------------------------------------------------------------
;; consumer for file processing
;;--------------------------------------------------------------
(defn- save-file
  "Save file to resources/public/uploads. "
  [src file-name]
  (let [target (io/file "resources" "public" "uploads" file-name)
        can-path (ensure-parent-dir! target)]   
    (io/copy src target)
    can-path))



;;--------------------------------------------------------------
;; Execute docker command
;; side effects!!!
;;
;; TODO: use channel as input
;;--------------------------------------------------------------
(defn- run-docker-version-command!
  "Run the docker version command and return relults"
  []
  (let [result @(exec/sh ["java" "-version"])]
    (if (some? (:out result))
      (assoc result :outstrlst (str/split (:out result) #"\n"))
      result)))




;;--------------------------------------------------------------
;; Execute docker command
;; side effects!!!
;;--------------------------------------------------------------
(defn run-command!
  "Run the docker version command and return relults"
  [data]
  (let [result @(exec/sh ["docker" "version"])]
    (if (some? (:out result))
      (assoc result :outstrlst (str/split (:out result) #"\n"))
      (assoc result :outstrlst (Throwable->map (:exception result))))))



;;--------------------------------------------------------------
;; Consumer for file processing
;;--------------------------------------------------------------
(defn start-processor
  "Waits for file events on channel and processes
  them asnynchronously
  input channel expected to contain a map
  :file-data - file data
  :file-name - name of file
  returns a map of input and output channels"
  []
  (let [in (async/chan 10)
        out (async/chan 10)
        chans {:input-chan in
               :output-chan out}]
    (async/go-loop [data (async/<! in)]
      (when data
        (when-let [path (save-file (:file-data data) (:file-name data))]
           (async/>! out (run-command! data)))
        (recur (async/<! in))))
    chans))


(defn stop-processor
  "Expects a map of the in and output channels
  and closes them"
  [chans]
  (map async/close! (vals chans)))


;;--------------------------------------------------------------
;; 
;;--------------------------------------------------------------
(defstate file-processor
  "File processor component lifecycle using Mount library"
  :start (start-processor)
  :stop (stop-processor file-processor))




